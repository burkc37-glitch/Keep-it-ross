# Keep It Ross — Runner Hunter

A first working version of the new broad-universe stock scanner. It searches active, tradable US equities available through Alpaca, ranks contraction / volume dry-up / higher-low / resistance-pressure / ignition setups, and exports candidates to CSV.

## Safety and limitations
- **Research/alert-only:** this code does not submit trades or create orders.
- **Paper account credentials only.** Use the API keys from your Alpaca paper account.
- It uses a heuristic score, not a proven prediction model. A high score is a candidate for review, not a guarantee of a runner.
- Short-interest and short-float fields are **not** included: Alpaca market bars alone cannot reliably establish them. Add a licensed/verified short-interest source separately.
- By default, it attempts to scan every eligible active, tradable US equity exposed by Alpaca. This is not every security listed in every US venue: Alpaca's asset list, data entitlements, and filters define the universe. For a quick test, set `MAX_SYMBOLS` to a positive number; capped runs sample the universe and can miss individual tickers.
- Alpaca's IEX feed may differ materially from consolidated market volume. If your account supports SIP data, set `ALPACA_DATA_FEED=sip`.
- For clean end-of-day signals, run after the regular session closes. During market hours, today's candle is partial.
- No automated buy/sell decisions are made. The -2% stop and +10% target are reference levels only.

## Setup

1. Install Python 3.10+.
2. In this folder, install packages:

   ```bash
   python -m pip install -r requirements.txt
   ```

3. Set environment variables using your **Alpaca PAPER** API keys:

   macOS/Linux:
   ```bash
   export APCA_API_KEY_ID="your_paper_key"
   export APCA_API_SECRET_KEY="your_paper_secret"
   ```

   Windows PowerShell:
   ```powershell
   $env:APCA_API_KEY_ID="your_paper_key"
   $env:APCA_API_SECRET_KEY="your_paper_secret"
   ```

4. Run:
   ```bash
   python runner_hunter.py
   ```

Results are written to `output/signals.csv` and `output/scanner.log`.

## Main settings

Environment variables:
- `MIN_SCORE=80` — strict A/A+ threshold.
- `MAX_SYMBOLS=0` — all eligible symbols; set a positive number for a smaller sampled test run.
- `BATCH_SIZE=100` — symbols per historical-bars request.
- `MIN_PRICE=2`, `MAX_PRICE=50`.
- `MIN_AVG_DOLLAR_VOLUME=2000000`.
- `ALPACA_DATA_FEED=iex` (or `sip` if entitled).
- `LOOKBACK_DAYS=150`.

## Next steps before relying on it
1. Validate the feed and request limits on the connected account.
2. Run historical, no-look-ahead backtests with realistic fills, gaps, slippage, and delisted symbols.
3. Measure the percentage hitting +10% within 20 trading days, and whether -2% was hit first.
4. Add validated short interest / float data as a separate factor.
5. Deploy as an alerting job only after tests pass. No paid service or live trading is enabled by this code.
